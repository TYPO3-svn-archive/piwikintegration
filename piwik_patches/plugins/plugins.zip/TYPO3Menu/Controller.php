<?php
class Piwik_TYPO3Menu_Controller extends Piwik_Controller 
{
	function index()
	{
		header('Location: index.php');
	}
}
?>
